# 小哈车控 v1.1.2 工程源码

## 编译环境
- JDK 17+
- Gradle 7.0+（已验证 Gradle 8/9 可用）
- Android SDK：platforms;android-34、build-tools;34.0.0

## 编译步骤
1. 用 Android Studio 打开本目录（或直接命令行）。
2. 新建 `local.properties`，写入 SDK 路径：
   ```
   sdk.dir=/你的Android/Sdk
   ```
3. 编译：
   ```
   gradle assembleRelease
   ```
   产物：`build/outputs/apk/release/DoroCar-release.apk`

## 目录说明
```
build.gradle          构建配置（签名、单元测试依赖）
settings.gradle       仓库配置
gradle.properties
keystore/             本次使用的签名（与原始 APK 不同，无法覆盖安装）
src/main/java/        反编译源码 + 本次修复
src/main/res/         资源
src/main/AndroidManifest.xml
src/test/java/        单元测试（Robolectric）
```

## 运行单元测试
```
gradle testDebugUnitTest
```
报告：`build/reports/tests/testDebugUnitTest/index.html`

## 本版本主要改动
1. `GwmSecureStore` / `SessionCodec`：凭据改为三副本冗余存储，去掉 AndroidKeyStore 依赖，
   修复"删后台再打开需要重新登录"。
2. `Base64Codec`：修复 `LOOKUP['=']` 误写成 `LOOKUP[61]` 导致含 `A` 的凭据解码错位。
3. `GwmClient.reviveSessionQuietly()`：修正续期顺序，先 refresh 再 initializeServices。
4. `GwmRepository`：冷启动静默校验，仅明确认证失败才判过期。
5. `MainActivity`：恢复期间显示"正在恢复登录…"，新增 onResume 同步会话状态。
6. `VehiclePollService`：START_STICKY + dataSync 前台服务类型。
7. `AndroidManifest.xml`：新增 data_extraction_rules，排除凭据的备份/迁移。

## 换成自己的签名
把 keystore 放到 `keystore/doro-release.jks`，在 `build.gradle` 的 `signingConfigs.release` 中
修改 `storePassword` / `keyAlias` / `keyPassword`，即可得到可覆盖升级安装的包。
