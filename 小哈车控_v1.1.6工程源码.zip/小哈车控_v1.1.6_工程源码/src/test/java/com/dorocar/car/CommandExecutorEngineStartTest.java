package com.dorocar.car;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.dorocar.car.vehicle.CommandExecutor;
import com.dorocar.car.vehicle.GwmRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


import static org.junit.Assert.assertNotNull;

/**
 * 回归测试：远程启动（ENGINE_START）走 4 参数 run 重载时，
 * 指令体列表必须被正确填充。此前该分支漏写 arrayList2.add(acBodyOf)，
 * 导致 sendSequentially 在空列表上 get(0) 抛 IndexOutOfBoundsException，
 * 点击"远程启动"直接闪退。
 */
@RunWith(AndroidJUnit4.class)
public class CommandExecutorEngineStartTest {

    @Before
    public void setUp() throws Exception {
        Context ctx = ApplicationProvider.getApplicationContext();
        new com.dorocar.car.vehicle.GwmSecureStore(ctx).clear();
        java.lang.reflect.Field f = GwmRepository.class.getDeclaredField("instance");
        f.setAccessible(true);
        f.set(null, null);
    }

    @Test
    public void 远程启动不抛下标越界() {
        Context ctx = ApplicationProvider.getApplicationContext();
        GwmRepository repo = GwmRepository.get(ctx);
        CommandExecutor executor = new CommandExecutor(ctx, repo);

        // 修复前：此调用在主线程同步抛 IndexOutOfBoundsException（arrayList2 为空）
        executor.run("ENGINE_START", null, 15, new CommandExecutor.Callback() {
            @Override
            public void onProgress(String s) {
            }

            @Override
            public void onResult(CommandExecutor.Result result) {
                assertNotNull(result);
                assertNotNull(result.message);
            }
        });
        // 修复前：此处在 arrayList2 为空时同步抛 IndexOutOfBoundsException；
        // 能正常走到这里（无论同步返回还是异步下发）即视为通过
    }

    @Test
    public void 空调关闭指令体列表长度一致() {
        Context ctx = ApplicationProvider.getApplicationContext();
        GwmRepository repo = GwmRepository.get(ctx);
        CommandExecutor executor = new CommandExecutor(ctx, repo);
        // 修复前：run() 末尾重复调用 sendSequentially，AC_OFF 会被下发两次
        executor.run("AC_OFF", null, new CommandExecutor.Callback() {
            @Override
            public void onProgress(String s) {
            }

            @Override
            public void onResult(CommandExecutor.Result result) {
            }
        });
    }
}
