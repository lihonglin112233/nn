package com.dorocar.car;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.dorocar.car.vehicle.GwmClient;
import com.dorocar.car.vehicle.GwmSecureStore;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * 登录态持久化回归测试：覆盖"杀掉后台再重新打开"必须保持登录的场景。
 */
@RunWith(AndroidJUnit4.class)
public class SessionPersistenceTest {

    private Context ctx;

    @Before
    public void setUp() {
        ctx = ApplicationProvider.getApplicationContext();
        new GwmSecureStore(ctx).clear();
    }

    @After
    public void tearDown() {
        new GwmSecureStore(ctx).clear();
    }

    private GwmClient sample() {
        GwmClient c = new GwmClient();
        c.phone = "13800138000";
        c.deviceId = "A1B2C3D4E5F60718293A4B5C6D7E8F90";
        c.gToken = "gt+/==";
        c.gRefreshToken = "rt+/==";
        c.ssoToken = "sso";
        c.userId = "u1";
        c.beanId = "b1";
        c.btAccessToken = "bt+/==";
        c.btRefreshToken = "btr";
        c.autoTokenId = "at+/==";
        c.autoUserId = "au1";
        return c;
    }

    private File internalFile() {
        return new File(ctx.getFilesDir(), "doro_gwm_session.json");
    }

    private File externalFile() {
        return new File(ctx.getExternalFilesDir(null), "doro_gwm_session.json");
    }

    private SharedPreferences prefs() {
        return ctx.getSharedPreferences("doro_gwm_secure", 0);
    }

    @Test
    public void 杀掉进程后重新打开仍是登录态() {
        new GwmSecureStore(ctx).save(sample());

        // 模拟进程被杀：全新建一个 store 实例读取
        GwmClient restored = new GwmSecureStore(ctx).load();

        assertNotNull("冷启动应能读回凭据", restored);
        assertTrue("读回后应为已登录", restored.isLoggedIn());
        assertEquals("gt+/==", restored.gToken);
        assertEquals("at+/==", restored.autoTokenId);
        assertEquals("A1B2C3D4E5F60718293A4B5C6D7E8F90", restored.deviceId);
    }

    @Test
    public void 三处副本都写入磁盘() {
        assertTrue(new GwmSecureStore(ctx).save(sample()));
        assertTrue(internalFile().length() > 0);
        assertTrue(externalFile().length() > 0);
        assertNotNull(prefs().getString("payload", null));
    }

    @Test
    public void 内部文件丢失仍能从其余副本恢复() {
        new GwmSecureStore(ctx).save(sample());
        assertTrue(internalFile().delete());

        GwmClient restored = new GwmSecureStore(ctx).load();
        assertNotNull(restored);
        assertTrue(restored.isLoggedIn());
        assertTrue("应自动回填内部文件", internalFile().length() > 0);
    }

    @Test
    public void SharedPreferences被清仍能从文件恢复() {
        new GwmSecureStore(ctx).save(sample());
        prefs().edit().clear().commit();

        GwmClient restored = new GwmSecureStore(ctx).load();
        assertNotNull(restored);
        assertTrue(restored.isLoggedIn());
    }

    @Test
    public void 全部副本损坏时清理脏数据并提示重新登录() throws Exception {
        new GwmSecureStore(ctx).save(sample());
        write(internalFile(), "@@broken@@");
        write(externalFile(), "@@broken@@");
        prefs().edit().putString("payload", "@@broken@@").commit();

        GwmSecureStore store = new GwmSecureStore(ctx);
        assertNull(store.load());
        assertNotNull(store.lastLoadError());
        assertTrue(store.lastLoadError().contains("重新登录"));
        assertFalse("脏数据应被清理，避免每次启动都失败", store.hasCredentials());
    }

    @Test
    public void 退出登录清除全部副本() {
        GwmSecureStore store = new GwmSecureStore(ctx);
        store.save(sample());
        store.clear();

        assertFalse(store.hasCredentials());
        assertNull(new GwmSecureStore(ctx).load());
    }

    @Test
    public void 凭据中带换行与特殊字符也能完整恢复() {
        GwmClient c = sample();
        c.gToken = "a+b/c=";
        c.gRefreshToken = "x/y+z==";
        c.ssoToken = "含中文的令牌";
        new GwmSecureStore(ctx).save(c);

        GwmClient restored = new GwmSecureStore(ctx).load();
        assertNotNull(restored);
        assertEquals("a+b/c=", restored.gToken);
        assertEquals("x/y+z==", restored.gRefreshToken);
        assertEquals("含中文的令牌", restored.ssoToken);
    }

    private static void write(File f, String content) throws Exception {
        java.io.FileOutputStream out = new java.io.FileOutputStream(f);
        try {
            out.write(content.getBytes("UTF-8"));
        } finally {
            out.close();
        }
    }
}
