package com.dorocar.car;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.dorocar.car.vehicle.GwmClient;
import com.dorocar.car.vehicle.GwmRepository;
import com.dorocar.car.vehicle.GwmSecureStore;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;

/**
 * 退出登录回归测试：logout() 必须同步生效。
 * 此前清理任务被排进单线程队列，若前面积压了网络请求/指令重试，
 * 界面会长时间停留在"已登录"；且旧任务持有的 client 还可能把凭据写回。
 */
@RunWith(AndroidJUnit4.class)
public class LogoutImmediateTest {

    private Context ctx;

    @Before
    public void setUp() throws Exception {
        ctx = ApplicationProvider.getApplicationContext();
        new GwmSecureStore(ctx).clear();
        resetSingleton();
    }

    @After
    public void tearDown() throws Exception {
        new GwmSecureStore(ctx).clear();
        resetSingleton();
    }

    private void resetSingleton() throws Exception {
        java.lang.reflect.Field f = GwmRepository.class.getDeclaredField("instance");
        f.setAccessible(true);
        f.set(null, null);
    }

    private GwmClient sample() {
        GwmClient c = new GwmClient();
        c.phone = "13800138000";
        c.deviceId = "A1B2C3D4E5F60718293A4B5C6D7E8F90";
        c.gToken = "gt+/==";
        c.gRefreshToken = "rt+/==";
        c.ssoToken = "sso";
        c.userId = "u1";
        c.beanId = "b1";
        c.btAccessToken = "bt+/==";
        c.btRefreshToken = "btr";
        c.autoTokenId = "at+/==";
        c.autoUserId = "au1";
        return c;
    }

    @Test
    public void 退出登录后立即处于未登录() {
        // 预置一份已保存的凭据，模拟已登录
        new GwmSecureStore(ctx).save(sample());
        GwmRepository repo = GwmRepository.get(ctx);
        // 单例构造会读盘恢复会话
        org.junit.Assert.assertTrue(repo.hasAccount());

        repo.logout();

        // 关键断言：logout 返回后（不等任何后台队列），立即是未登录
        org.junit.Assert.assertFalse(repo.isLoggedIn());
        assertNull(repo.selectedVehicle());
        assertEquals(GwmRepository.SessionState.LOGGED_OUT, repo.sessionState());
        // 本地凭据三副本应已全部清除
        assertFalse(new GwmSecureStore(ctx).hasCredentials());
    }
}
