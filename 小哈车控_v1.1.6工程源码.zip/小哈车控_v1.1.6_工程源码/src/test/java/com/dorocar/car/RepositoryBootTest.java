package com.dorocar.car;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.dorocar.car.vehicle.GwmClient;
import com.dorocar.car.vehicle.GwmRepository;
import com.dorocar.car.vehicle.GwmSecureStore;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * 仓库层冷启动恢复流程：本地已有凭据时，启动即应处于"可用会话"，
 * 而不是因为无法联网/无法续期就把用户踢回登录页。
 */
@RunWith(AndroidJUnit4.class)
public class RepositoryBootTest {

    private Context ctx;

    @Before
    public void setUp() throws Exception {
        ctx = ApplicationProvider.getApplicationContext();
        new GwmSecureStore(ctx).clear();
        resetSingleton();
    }

    @After
    public void tearDown() throws Exception {
        new GwmSecureStore(ctx).clear();
        resetSingleton();
    }

    private static void resetSingleton() throws Exception {
        java.lang.reflect.Field f = GwmRepository.class.getDeclaredField("instance");
        f.setAccessible(true);
        f.set(null, null);
    }

    private GwmClient completeClient() {
        GwmClient c = new GwmClient();
        c.phone = "13800138000";
        c.deviceId = "A1B2C3D4E5F60718293A4B5C6D7E8F90";
        c.gToken = "gt";
        c.gRefreshToken = "rt";
        c.ssoToken = "sso";
        c.userId = "u1";
        c.beanId = "b1";
        c.btAccessToken = "bt";
        c.btRefreshToken = "btr";
        c.autoTokenId = "at";
        c.autoUserId = "au1";
        return c;
    }

    @Test
    public void 本地有完整凭据时启动即为登录态() {
        new GwmSecureStore(ctx).save(completeClient());

        GwmRepository repo = GwmRepository.get(ctx);

        assertTrue("启动即为登录态", repo.isLoggedIn());
        assertEquals(GwmRepository.SessionState.ACTIVE, repo.sessionState());
        assertTrue("会话可用", repo.isSessionUsable());
        assertEquals("13800138000", repo.phone());
    }

    @Test
    public void 没有凭据时启动为未登录() {
        GwmRepository repo = GwmRepository.get(ctx);
        assertFalse(repo.isLoggedIn());
        assertEquals(GwmRepository.SessionState.LOGGED_OUT, repo.sessionState());
    }

    @Test
    public void 只有刷新令牌时进入恢复流程而非直接踢下线() {
        GwmClient c = completeClient();
        c.beanId = null;
        c.btAccessToken = null;
        c.autoTokenId = null;
        c.autoUserId = null;
        new GwmSecureStore(ctx).save(c);

        GwmRepository repo = GwmRepository.get(ctx);

        assertFalse(repo.isLoggedIn());
        assertEquals("有刷新令牌时应先尝试静默恢复",
                GwmRepository.SessionState.RESTORING, repo.sessionState());
    }
}
